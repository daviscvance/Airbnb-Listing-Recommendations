#!/bin/bash

echo "Setup for new environment"

sudo apt-get update
sudo apt-get -y  install python3-pip
sudo apt-get update

echo "Python Packages:"
pip3 install --upgrade pip3
pip3 install -r requirements.txt

pip3 freeze --local | grep -v '^\-e' | cut -d = -f 1  | xargs -n1 pip3 install -U
